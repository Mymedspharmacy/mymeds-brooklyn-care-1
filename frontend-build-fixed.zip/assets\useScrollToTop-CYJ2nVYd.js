import{r as o}from"./router-CAXMQKvB.js";const r=(r=[])=>{o.useEffect(()=>{try{window.scrollTo({top:0,left:0,behavior:"smooth"})}catch(o){window.scrollTo(0,0)}},r)};export{r as u};
